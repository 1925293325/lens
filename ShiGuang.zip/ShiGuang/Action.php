<?php
/**
 * ShiGuang Action
 * 处理 /shiguang 路由
 */

namespace TypechoPlugin\ShiGuang;

use Typecho\Widget;
use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}

class Action extends Widget
{
    public function render()
    {
        $opts = Options::alloc()->plugin('ShiGuang');
        $gridColumns = intval($opts->gridColumns) ?: 3;
        
        $allArticles = [];
        try {
            if (class_exists('TypechoPlugin\ShiGuang\Plugin')) {
                $allArticles = \TypechoPlugin\ShiGuang\Plugin::getAlbumData();
            }
        } catch (\Throwable $e) {
            $allArticles = [];
        }
        
        $pluginUrl = Options::alloc()->pluginUrl . '/ShiGuang';
        $albumTitle = $opts->title ?? '我的相册';
        $albumDesc = $opts->description ?? '';
        $headerBg = !empty($opts->headerBg) 
            ? (strpos($opts->headerBg, 'http') === 0 ? $opts->headerBg : $pluginUrl . '/' . ltrim($opts->headerBg, '/'))
            : '';
        
        $pageTitle = $albumTitle;
        
        $viewFile = __DIR__ . '/views/shiguang.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            echo '<p style="text-align:center;padding:80px 20px;color:#999;">视图文件丢失，请重新启用插件</p>';
        }
    }
}
