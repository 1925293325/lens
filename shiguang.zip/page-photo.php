<?php
/**
 * 拾光·极简相册
 *
 * @package custom
 * @template Photo
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('header.php');

$opts = $this->options->plugin('ShiGuang');
$gridColumns = intval($opts->gridColumns) ?: 3;

$allArticles = [];
try {
    if (class_exists('TypechoPlugin\ShiGuang\Plugin')) {
        $allArticles = \TypechoPlugin\ShiGuang\Plugin::getAlbumData();
    }
} catch (\Throwable $e) { $allArticles = []; }

$pluginUrl = $this->options->pluginUrl . '/ShiGuang';
?>

<link rel="stylesheet" href="<?= $pluginUrl ?>/views/shiguang.css?v=3">
<style>
/* 拾光灯箱 - 修复版 */
.sg-lightbox {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 2147483647;
    overflow: hidden;
}
.sg-lightbox.active {
    display: block;
}

.sg-lightbox-backdrop {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.92);
    z-index: 1;
}

.sg-lightbox-stage {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: clamp(16px, 4vh, 48px);
    box-sizing: border-box;
    z-index: 2;
}
.sg-lightbox-imgbox {
    width: 100%;
    height: 100%;
    max-width: 100%;
    max-height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}
.sg-lightbox-img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
    border-radius: 12px;
    box-shadow: 0 16px 48px rgba(0,0,0,0.5);
    transition: opacity .2s ease-out, transform .2s ease-out;
}

.sg-lightbox-bar {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: clamp(16px, 3vh, 24px) 0;
    box-sizing: border-box;
    z-index: 2;
    background: linear-gradient(0deg, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0) 100%);
}

.sg-lb-main {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    width: 100%;
    max-width: 600px;
    padding: 0 16px;
    box-sizing: border-box;
}

.sg-lb-pill {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 40px;
    padding: 0 20px;
    border-radius: 9999px;
    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(255,255,255,0.08);
    color: rgba(255,255,255,0.65);
    cursor: pointer;
    flex-shrink: 0;
    transition: background .2s ease, color .2s ease, transform .1s ease-out;
    -webkit-tap-highlight-color: transparent;
    font: inherit;
}
.sg-lb-pill:hover {
    background: rgba(255,255,255,0.14);
    color: rgba(255,255,255,0.9);
}
.sg-lb-pill:active {
    transform: scale(0.95);
}
.sg-lb-pill.disabled {
    opacity: 0.25;
    pointer-events: none;
}
.sg-lb-pill svg {
    width: 20px;
    height: 20px;
    stroke: currentColor;
    fill: none;
    stroke-width: 2;
    stroke-linecap: round;
    stroke-linejoin: round;
}

.sg-lb-title-pill {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    height: 40px;
    padding: 0 16px;
    border-radius: 9999px;
    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(255,255,255,0.08);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    flex: 1;
    max-width: 300px;
}
.sg-lightbox-title {
    font-size: 14px;
    color: rgba(255,255,255,0.7);
    text-align: center;
    width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.sg-lightbox-close-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: rgba(255,255,255,0.08);
    border: none;
    color: rgba(255,255,255,0.6);
    cursor: pointer;
    flex-shrink: 0;
    padding: 0;
    transition: background .15s ease, color .15s ease, transform .1s ease-out;
}
.sg-lightbox-close-btn:hover {
    background: rgba(255,255,255,0.15);
    color: rgba(255,255,255,0.9);
}
.sg-lightbox-close-btn:active {
    transform: scale(0.95);
}
.sg-lightbox-close-btn svg {
    width: 14px;
    height: 14px;
    stroke: currentColor;
    fill: none;
    stroke-width: 2.5;
    stroke-linecap: round;
    stroke-linejoin: round;
}

.sg-lightbox-counter {
    margin-top: 8px;
    font-size: 12px;
    color: rgba(255,255,255,0.35);
    letter-spacing: 0.05em;
    text-align: center;
}

.sg-lightbox-thumbs {
    display: flex;
    justify-content: center;
    gap: 6px;
    margin-top: 8px;
    overflow-x: auto;
    max-width: 100%;
    padding: 0 16px 4px;
    scrollbar-width: none;
    -ms-overflow-style: none;
}
.sg-lightbox-thumbs::-webkit-scrollbar {
    display: none;
}
.sg-lb-thumb {
    flex-shrink: 0;
    width: 44px;
    height: 32px;
    border-radius: 4px;
    overflow: hidden;
    opacity: 0.4;
    cursor: pointer;
    border: 2px solid transparent;
    transition: opacity .2s, border-color .2s;
}
.sg-lb-thumb img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}
.sg-lb-thumb:hover {
    opacity: 0.7;
}
.sg-lb-thumb.active {
    opacity: 1;
    border-color: rgba(255,255,255,0.5);
}
</style>

<div class="main">
    <?php $this->need('module/head2.php');?>

    <div class="page_thumb blur">
        <div class="post_bg lazy-load" data-src="<?php echo $this->fields->thumb ? $this->fields->thumb : Helper::options()->themeUrl . '/static/img/photo.jpg'; ?>"></div>
        <div class="pc">
            <i class="iconfont icon-nav menu-button"></i>
            <div class="page-head">
                <?php if ($this->options->logoStyle == 'text') {?>
                <h1><a href="<?php $this->options->siteUrl(); ?>"><?php $this->options->title();?></a><span class="soul">生活志</span></h1>
                <?php }else{ ?>
                <a class="logo" href="<?php $this->options->siteUrl(); ?>">
                    <img src="<?php echo $this->options->logoWhite ? $this->options->logoWhite : Helper::options()->themeUrl . '/static/img/logoWhite.svg'; ?>">
                </a>
                <?php }?>
            </div>
        </div>
        <div class="m">
            <h1 class="page-head"><?php $this->archiveTitle(' &raquo; ', ''); ?><span>Scenery along the way</span></h1>
        </div>
    </div>

    <div class="page-title animate__animated animate__fadeIn pc">
        <h1><?php $this->title(); ?></h1>
    </div>

    <div class="photo-contain blur animate__animated animate__fadeIn">
        <div class="sg-wrap">
            <main>
<?php if (empty($allArticles)): ?>
                <div class="sg-empty">
                    <div class="icon">📷</div>
                    <div class="txt">暂无图片</div>
                </div>
<?php else: ?>

<?php if ($gridColumns == 2): ?>
<div class="sg-waterfall" id="sgWaterfall">
<?php $articleIndex = 0; foreach ($allArticles as $article):
    $isSingle = $article['count'] <= 1;
    $firstImg = $article['images'][0];
    $delay = min($articleIndex * 0.08, 0.8);
?>
  <div class="sg-wf-item sg-reveal"
       data-index="<?= $articleIndex ?>"
       data-cid="<?= $article['cid'] ?>"
       style="animation-delay: <?= $delay ?>s">
    <div class="sg-wf-visual">
      <img src="<?= htmlspecialchars($firstImg['thumb']) ?>"
           alt="<?= htmlspecialchars($article['title']) ?>"
           loading="lazy">
      <?php if (!$isSingle): ?>
      <div class="sg-wf-count"><?= $article['count'] ?></div>
      <?php endif; ?>
    </div>
    <div class="sg-wf-body">
      <div class="sg-wf-title"><?= htmlspecialchars($article['title']) ?></div>
      <div class="sg-wf-date"><?= htmlspecialchars($article['date']) ?></div>
    </div>
  </div>
<?php $articleIndex++; endforeach; ?>
</div>

<?php else: ?>
<?php
$flatImages = [];
foreach ($allArticles as $article) {
    foreach ($article['images'] as $img) {
        $flatImages[] = [
            'url'       => $img['url'],
            'thumb'     => $img['thumb'],
            'title'     => $article['title']
        ];
    }
}
?>
<div class="sg-3col" id="sg3col">
<?php $globalIndex = 0; foreach ($flatImages as $img): ?>
  <div class="sg-photo sg-reveal"
       data-index="<?= $globalIndex ?>"
       data-url="<?= htmlspecialchars($img['url']) ?>"
       data-title="<?= htmlspecialchars($img['title']) ?>"
       data-thumb="<?= htmlspecialchars($img['thumb']) ?>"
       style="animation-delay: <?= min(($globalIndex % 9) * 0.06, 0.5) ?>s">
    <div class="sg-photo-inner">
      <img src="<?= htmlspecialchars($img['thumb']) ?>" alt="" loading="lazy">
    </div>
  </div>
<?php $globalIndex++; endforeach; ?>
</div>
<?php endif; ?>

<?php endif; ?>
            </main>

            <div class="sg-lightbox" id="sgLightbox">
                <div class="sg-lightbox-backdrop" id="sgLbBackdrop"></div>

                <div class="sg-lightbox-stage" id="sgLbStage">
                    <div class="sg-lightbox-imgbox" id="sgLbImgbox">
                        <img class="sg-lightbox-img" id="sgLbImg" src="" alt="" draggable="false">
                    </div>
                </div>

                <div class="sg-lightbox-bar">
                    <div class="sg-lb-main">
                        <button class="sg-lb-pill prev" id="sgLbPrev" aria-label="上一张">
                            <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
                        </button>

                        <div class="sg-lb-title-pill">
                            <div class="sg-lightbox-title" id="sgLbTitle">图片</div>
                            <button class="sg-lightbox-close-btn" id="sgLbClose" aria-label="关闭">
                                <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            </button>
                        </div>

                        <button class="sg-lb-pill next" id="sgLbNext" aria-label="下一张">
                            <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
                        </button>
                    </div>

                    <div class="sg-lightbox-counter" id="sgLbCounter">1 / 1</div>
                    <div class="sg-lightbox-thumbs" id="sgLbThumbs"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<a id="gototop" class="hidden"><i class="iconfont icon-up"></i></a>

<script>
const sgArticles = <?= json_encode($allArticles) ?>;
let sgFlatImages = [];
let sgMode = '<?= $gridColumns == 2 ? 'article' : 'single' ?>';

if (sgMode === 'single') {
    sgArticles.forEach(article => {
        article.images.forEach(img => {
            sgFlatImages.push({ url: img.url, thumb: img.thumb, title: article.title });
        });
    });
}

const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            revealObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.05, rootMargin: '0px 0px -30px 0px' });

document.querySelectorAll('.sg-reveal').forEach(el => revealObserver.observe(el));

let sgCurrentImages = [];
let sgCurrentIndex = 0;
const sgLightbox = document.getElementById('sgLightbox');
const sgLbImg = document.getElementById('sgLbImg');
const sgLbTitle = document.getElementById('sgLbTitle');
const sgLbCounter = document.getElementById('sgLbCounter');
const sgLbThumbs = document.getElementById('sgLbThumbs');
const sgLbPrev = document.getElementById('sgLbPrev');
const sgLbNext = document.getElementById('sgLbNext');
const sgLbClose = document.getElementById('sgLbClose');
const sgLbStage = document.getElementById('sgLbStage');
const sgLbImgbox = document.getElementById('sgLbImgbox');
const sgLbBackdrop = document.getElementById('sgLbBackdrop');

function getHideElements() {
    const selectors = ['.page_thumb', '.page-title', '.page_head', '.header', '.navbar', '.nav-bar', '.top-bar', '.site-header', '#header', '.fixed-header', '.menu-button', '.icon-nav'];
    const els = [];
    selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach(el => els.push(el));
    });
    return els;
}

let hiddenElements = [];

function sgOpen(images, index, title) {
    sgCurrentImages = images;
    sgCurrentIndex = index;
    sgLbTitle.textContent = title || '图片';
    sgUpdateLb();
    sgLightbox.classList.add('active');
    document.body.style.overflow = 'hidden';

    hiddenElements = getHideElements();
    hiddenElements.forEach(el => { el.style.visibility = 'hidden'; });
}

function sgUpdateLb() {
    if (!sgCurrentImages.length) return;
    const img = sgCurrentImages[sgCurrentIndex];

    sgLbImg.style.opacity = '0';
    sgLbImg.style.transform = 'scale(0.92)';

    setTimeout(() => {
        const onImgLoad = function() {
            sgLbImg.style.opacity = '1';
            sgLbImg.style.transform = 'scale(1)';
            sgLbImg.removeEventListener('load', onImgLoad);
        };
        sgLbImg.addEventListener('load', onImgLoad);

        sgLbImg.src = img.url;
        sgLbImg.alt = img.title || '图片';

        if (sgLbImg.complete && sgLbImg.naturalWidth > 0) {
            onImgLoad();
        }
    }, 120);

    sgLbCounter.textContent = (sgCurrentIndex + 1) + ' / ' + sgCurrentImages.length;

    sgLbThumbs.innerHTML = sgCurrentImages.map((item, idx) =>
        '<div class="sg-lb-thumb ' + (idx === sgCurrentIndex ? 'active' : '') + '" data-index="' + idx + '">' +
        '<img src="' + item.thumb + '" alt="" loading="lazy" draggable="false">' +
        '</div>'
    ).join('');

    sgLbThumbs.querySelectorAll('.sg-lb-thumb').forEach(item => {
        item.addEventListener('click', () => {
            sgCurrentIndex = parseInt(item.dataset.index);
            sgUpdateLb();
        });
    });

    sgLbPrev.classList.toggle('disabled', sgCurrentIndex === 0);
    sgLbNext.classList.toggle('disabled', sgCurrentIndex === sgCurrentImages.length - 1);
}

function sgPrev() {
    if (sgCurrentIndex > 0) { sgCurrentIndex--; sgUpdateLb(); }
}
function sgNext() {
    if (sgCurrentIndex < sgCurrentImages.length - 1) { sgCurrentIndex++; sgUpdateLb(); }
}
function sgClose() {
    sgLightbox.classList.remove('active');
    document.body.style.overflow = '';
    sgLbImg.style.opacity = '0';
    sgLbImg.style.transform = 'scale(0.92)';

    hiddenElements.forEach(el => { el.style.visibility = ''; });
    hiddenElements = [];
}

document.querySelectorAll('.sg-wf-item').forEach((card, idx) => {
    card.addEventListener('click', () => {
        const article = sgArticles[idx];
        if (article && article.images) {
            sgOpen(article.images, 0, article.title);
        }
    });
});

document.querySelectorAll('.sg-photo').forEach((item, idx) => {
    item.addEventListener('click', () => {
        if (sgFlatImages[idx]) {
            sgOpen(sgFlatImages, idx, sgFlatImages[idx].title);
        }
    });
});

sgLbClose.addEventListener('click', sgClose);
sgLbPrev.addEventListener('click', sgPrev);
sgLbNext.addEventListener('click', sgNext);

sgLbBackdrop.addEventListener('click', sgClose);
sgLbStage.addEventListener('click', (e) => {
    if (e.target === sgLbStage || e.target === sgLbImgbox) sgClose();
});

document.addEventListener('keydown', (e) => {
    if (!sgLightbox.classList.contains('active')) return;
    if (e.key === 'ArrowLeft') sgPrev();
    if (e.key === 'ArrowRight') sgNext();
    if (e.key === 'Escape') sgClose();
});

let sgTouchX = 0;
if (sgLbStage) {
    sgLbStage.addEventListener('touchstart', (e) => {
        sgTouchX = e.changedTouches[0].screenX;
    }, { passive: true });
    sgLbStage.addEventListener('touchend', (e) => {
        const diff = sgTouchX - e.changedTouches[0].screenX;
        if (Math.abs(diff) > 60) { diff > 0 ? sgNext() : sgPrev(); }
    }, { passive: true });
}
</script>

<?php $this->need('footer.php'); ?>
