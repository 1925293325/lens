<?php
/**
 * /shiguang 路由专用视图
 */

use Widget\Options;

if (!defined('__TYPECHO_ROOT_DIR__')) exit;

$opts = Options::alloc()->plugin('ShiGuang');
$gridColumns = intval($opts->gridColumns) ?: 3;

$allArticles = [];
try {
    if (class_exists('TypechoPlugin\ShiGuang\Plugin')) {
        $allArticles = \TypechoPlugin\ShiGuang\Plugin::getAlbumData();
    }
} catch (\Throwable $e) { $allArticles = []; }

$pluginUrl = Options::alloc()->pluginUrl . '/ShiGuang';
$albumTitle = $opts->title ?? '我的相册';
$albumDesc = $opts->description ?? '';
$headerBg = !empty($opts->headerBg)
    ? (strpos($opts->headerBg, 'http') === 0 ? $opts->headerBg : $pluginUrl . '/' . ltrim($opts->headerBg, '/'))
    : '';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?= htmlspecialchars($albumTitle) ?></title>
    <link rel="stylesheet" href="<?= $pluginUrl ?>/views/shiguang.css?v=3">
    <style>
        .sg-hero {
            position: relative;
            height: 28vh;
            min-height: 160px;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            padding: 0 16px 20px;
            background: linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0.55) 100%), url('<?= htmlspecialchars($headerBg) ?>') center/cover no-repeat;
            color: #fff;
        }
        .sg-hero h1 { font-size: 1.6rem; font-weight: 700; margin: 0 0 6px; letter-spacing: 1px; }
        .sg-hero p { font-size: 0.8rem; opacity: 0.75; margin: 0; }
        @media (min-width: 768px) {
            .sg-hero { height: 24vh; min-height: 200px; padding: 0 24px 28px; }
            .sg-hero h1 { font-size: 2rem; }
            .sg-hero p { font-size: 0.9rem; }
        }
    </style>
</head>
<body>

<!-- 手机端顶栏 -->
<div class="sg-mobile-header">
    <a href="javascript:history.back()" class="sg-back">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
    </a>
    <h1><?= htmlspecialchars($albumTitle) ?></h1>
    <span style="width:24px;"></span>
</div>

<div class="sg-hero">
    <h1><?= htmlspecialchars($albumTitle) ?></h1>
    <p><?= htmlspecialchars($albumDesc) ?></p>
</div>

<div class="sg-page">
    <div class="sg-wrap">
        <main>
<?php if (empty($allArticles)): ?>
            <div class="sg-empty">
                <div class="icon">📷</div>
                <div class="txt">暂无图片</div>
            </div>
<?php else: ?>

<?php if ($gridColumns == 2): ?>
<div class="sg-waterfall" id="sgWaterfall">
<?php $articleIndex = 0; foreach ($allArticles as $article):
    $isSingle = $article['count'] <= 1;
    $firstImg = $article['images'][0];
    $delay = min($articleIndex * 0.08, 0.8);
?>
  <div class="sg-wf-item sg-reveal"
       data-index="<?= $articleIndex ?>"
       data-cid="<?= $article['cid'] ?>"
       style="animation-delay: <?= $delay ?>s">
    <div class="sg-wf-visual">
      <img src="<?= htmlspecialchars($firstImg['thumb']) ?>"
           alt="<?= htmlspecialchars($article['title']) ?>"
           loading="lazy">
      <?php if (!$isSingle): ?>
      <div class="sg-wf-count"><?= $article['count'] ?></div>
      <?php endif; ?>
    </div>
    <div class="sg-wf-body">
      <div class="sg-wf-title"><?= htmlspecialchars($article['title']) ?></div>
      <div class="sg-wf-date"><?= htmlspecialchars($article['date']) ?></div>
    </div>
  </div>
<?php $articleIndex++; endforeach; ?>
</div>

<?php else: ?>
<?php
$flatImages = [];
foreach ($allArticles as $article) {
    foreach ($article['images'] as $img) {
        $flatImages[] = [
            'url'       => $img['url'],
            'thumb'     => $img['thumb'],
            'title'     => $article['title']
        ];
    }
}
?>
<div class="sg-3col" id="sg3col">
<?php $globalIndex = 0; foreach ($flatImages as $img): ?>
  <div class="sg-photo sg-reveal"
       data-index="<?= $globalIndex ?>"
       data-url="<?= htmlspecialchars($img['url']) ?>"
       data-title="<?= htmlspecialchars($img['title']) ?>"
       data-thumb="<?= htmlspecialchars($img['thumb']) ?>"
       style="animation-delay: <?= min(($globalIndex % 9) * 0.06, 0.5) ?>s">
    <div class="sg-photo-inner">
      <img src="<?= htmlspecialchars($img['thumb']) ?>" alt="" loading="lazy">
    </div>
  </div>
<?php $globalIndex++; endforeach; ?>
</div>
<?php endif; ?>

<?php endif; ?>
        </main>

        <!-- 现代灯箱（修复版） -->
        <div class="sg-lightbox" id="sgLightbox">
            <div class="sg-lightbox-backdrop" id="sgLbBackdrop"></div>

            <!-- 图片区域 -->
            <div class="sg-lightbox-stage" id="sgLbStage">
                <div class="sg-lightbox-imgbox" id="sgLbImgbox">
                    <img class="sg-lightbox-img" id="sgLbImg" src="" alt="" draggable="false">
                </div>
            </div>

            <!-- 底部栏：固定底部 -->
            <div class="sg-lightbox-bar">
                <div class="sg-lb-main">
                    <button class="sg-lb-pill prev" id="sgLbPrev" aria-label="上一张">
                        <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
                    </button>

                    <div class="sg-lb-title-pill">
                        <div class="sg-lightbox-title" id="sgLbTitle">图片</div>
                        <button class="sg-lightbox-close-btn" id="sgLbClose" aria-label="关闭">
                            <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                        </button>
                    </div>

                    <button class="sg-lb-pill next" id="sgLbNext" aria-label="下一张">
                        <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
                    </button>
                </div>

                <div class="sg-lightbox-counter" id="sgLbCounter">1 / 1</div>
                <div class="sg-lightbox-thumbs" id="sgLbThumbs"></div>
            </div>
        </div>
    </div>
</div>

<script>
const sgArticles = <?= json_encode($allArticles) ?>;
let sgFlatImages = [];
let sgMode = '<?= $gridColumns == 2 ? 'article' : 'single' ?>';

if (sgMode === 'single') {
    sgArticles.forEach(article => {
        article.images.forEach(img => {
            sgFlatImages.push({ url: img.url, thumb: img.thumb, title: article.title });
        });
    });
}

const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            revealObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.05, rootMargin: '0px 0px -30px 0px' });

document.querySelectorAll('.sg-reveal').forEach(el => revealObserver.observe(el));

let sgCurrentImages = [];
let sgCurrentIndex = 0;
const sgLightbox = document.getElementById('sgLightbox');
const sgLbImg = document.getElementById('sgLbImg');
const sgLbTitle = document.getElementById('sgLbTitle');
const sgLbCounter = document.getElementById('sgLbCounter');
const sgLbThumbs = document.getElementById('sgLbThumbs');
const sgLbPrev = document.getElementById('sgLbPrev');
const sgLbNext = document.getElementById('sgLbNext');
const sgLbClose = document.getElementById('sgLbClose');
const sgLbStage = document.getElementById('sgLbStage');
const sgLbImgbox = document.getElementById('sgLbImgbox');
const sgLbBackdrop = document.getElementById('sgLbBackdrop');

function sgOpen(images, index, title) {
    sgCurrentImages = images;
    sgCurrentIndex = index;
    sgLbTitle.textContent = title || '图片';
    sgUpdateLb();
    sgLightbox.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function sgUpdateLb() {
    if (!sgCurrentImages.length) return;
    const img = sgCurrentImages[sgCurrentIndex];

    sgLbImg.style.opacity = '0';
    sgLbImg.style.transform = 'scale(0.92)';

    setTimeout(() => {
        const onImgLoad = function() {
            sgLbImg.style.opacity = '1';
            sgLbImg.style.transform = 'scale(1)';
            sgLbImg.removeEventListener('load', onImgLoad);
        };
        sgLbImg.addEventListener('load', onImgLoad);

        sgLbImg.src = img.url;
        sgLbImg.alt = img.title || '图片';

        if (sgLbImg.complete && sgLbImg.naturalWidth > 0) {
            onImgLoad();
        }
    }, 120);

    sgLbCounter.textContent = (sgCurrentIndex + 1) + ' / ' + sgCurrentImages.length;

    sgLbThumbs.innerHTML = sgCurrentImages.map((item, idx) =>
        '<div class="sg-lb-thumb ' + (idx === sgCurrentIndex ? 'active' : '') + '" data-index="' + idx + '">' +
        '<img src="' + item.thumb + '" alt="" loading="lazy" draggable="false">' +
        '</div>'
    ).join('');

    sgLbThumbs.querySelectorAll('.sg-lb-thumb').forEach(item => {
        item.addEventListener('click', () => {
            sgCurrentIndex = parseInt(item.dataset.index);
            sgUpdateLb();
        });
    });

    sgLbPrev.classList.toggle('disabled', sgCurrentIndex === 0);
    sgLbNext.classList.toggle('disabled', sgCurrentIndex === sgCurrentImages.length - 1);
}

function sgPrev() {
    if (sgCurrentIndex > 0) { sgCurrentIndex--; sgUpdateLb(); }
}
function sgNext() {
    if (sgCurrentIndex < sgCurrentImages.length - 1) { sgCurrentIndex++; sgUpdateLb(); }
}
function sgClose() {
    sgLightbox.classList.remove('active');
    document.body.style.overflow = '';
    sgLbImg.style.opacity = '0';
    sgLbImg.style.transform = 'scale(0.92)';
}

document.querySelectorAll('.sg-wf-item').forEach((card, idx) => {
    card.addEventListener('click', () => {
        const article = sgArticles[idx];
        if (article && article.images) {
            sgOpen(article.images, 0, article.title);
        }
    });
});

document.querySelectorAll('.sg-photo').forEach((item, idx) => {
    item.addEventListener('click', () => {
        if (sgFlatImages[idx]) {
            sgOpen(sgFlatImages, idx, sgFlatImages[idx].title);
        }
    });
});

sgLbClose.addEventListener('click', sgClose);
sgLbPrev.addEventListener('click', sgPrev);
sgLbNext.addEventListener('click', sgNext);

sgLbBackdrop.addEventListener('click', sgClose);
sgLbStage.addEventListener('click', (e) => {
    if (e.target === sgLbStage || e.target === sgLbImgbox) sgClose();
});

document.addEventListener('keydown', (e) => {
    if (!sgLightbox.classList.contains('active')) return;
    if (e.key === 'ArrowLeft') sgPrev();
    if (e.key === 'ArrowRight') sgNext();
    if (e.key === 'Escape') sgClose();
});

let sgTouchX = 0;
if (sgLbStage) {
    sgLbStage.addEventListener('touchstart', (e) => {
        sgTouchX = e.changedTouches[0].screenX;
    }, { passive: true });
    sgLbStage.addEventListener('touchend', (e) => {
        const diff = sgTouchX - e.changedTouches[0].screenX;
        if (Math.abs(diff) > 60) { diff > 0 ? sgNext() : sgPrev(); }
    }, { passive: true });
}
</script>

</body>
</html>