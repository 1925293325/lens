<?php
/**
 * 相册模板
 * 变量由 Action.php 传入：
 * - $pageTitle: 页面标题
 * - $albumTitle: 相册主标题
 * - $albumDesc: 相册副标题
 * - $headerBg: 头部背景图
 * - $articles: 文章图片数据
 * - $allImages: 所有图片平铺数组
 * - $options: 插件配置对象
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="<?php echo \Widget\Options::alloc()->charset(); ?>">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- 引入优质中文字体 -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@300;400;500;700&family=Noto+Serif+SC:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        /* === 基础样式 === */
        :root{
            --theme:#ff5a5f;
            --bg:#fafafa;
            --glass:rgba(255,255,255,.15);
            --font-sans: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            --font-serif: 'Noto Serif SC', "Source Han Serif SC", "STSong", "SimSun", serif;
        }
        *{box-sizing:border-box;margin:0;padding:0;font-family:var(--font-sans);}
        body{background:var(--bg);color:#333;overflow-x:hidden;font-weight:400;line-height:1.6;}
        
        /* === 透明顶栏 === */
        .top-bar{position:fixed;top:0;left:0;right:0;height:56px;background:var(--glass);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border-bottom:1px solid rgba(255,255,255,.2);z-index:1000;display:flex;align-items:center;justify-content:center;padding:0 20px;}
        .top-bar-title{font-size:1.3rem;font-weight:600;color:#fff;letter-spacing:3px;text-shadow:0 2px 4px rgba(0,0,0,.3);font-family:var(--font-serif);}
        
        /* === 头部样式 === */
        header{position:relative;height:50vh;min-height:300px;background:url("<?php echo htmlspecialchars($headerBg); ?>") center/cover;display:flex;align-items:center;justify-content:center;border-radius:0 0 30px 30px;overflow:hidden;margin-top:0;}
        header::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.3) 0%,rgba(0,0,0,.5) 100%);}
        
        /* === 副标题居中放大 === */
        .header-content{position:relative;z-index:2;text-align:center;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;padding-top:30px;}
        .header-subtitle{font-size:1.8rem;font-weight:600;letter-spacing:4px;opacity:.95;text-shadow:0 2px 8px rgba(0,0,0,.4);margin-top:-20px;font-family:var(--font-serif);font-weight:300;}
        
        /* === 音乐播放器样式 === */
        .music-player{position:sticky;top:66px;z-index:100;max-width:800px;margin:40px auto 30px;background:rgba(255,255,255,.85);backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,.6);border-radius:18px;box-shadow:0 8px 32px rgba(0,0,0,.08);padding:18px 20px;display:flex;align-items:center;gap:14px;}
        .player-btn{width:46px;height:46px;border-radius:50%;background:var(--theme);color:#fff;border:none;cursor:pointer;display:grid;place-content:center;font-size:20px;transition:transform 0.2s,box-shadow 0.2s;}
        .player-btn:hover{transform:scale(1.05);box-shadow:0 4px 12px rgba(255,90,95,.4);}
        .tri-play {display: inline-block;width: 0;height: 0;border-style: solid;border-width: 10px 0 10px 16px;border-color: transparent transparent transparent #ffffff;margin-left: 2px;}
        .tri-pause {display: flex;align-items: center;justify-content: space-between;width: 16px;height: 16px;}
        .tri-pause::before,.tri-pause::after {content: '';display: block;width: 5px;height: 100%;background-color: #ffffff;}
        .player-info{flex:1;}
        .player-info .title{font-weight:500;margin-bottom:4px;font-size:14px;letter-spacing:0.5px;}
        .player-info .time{font-size:12px;color:#666;font-weight:400;}
        .progress{width:100%;height:4px;background:rgba(0,0,0,.08);border-radius:2px;margin:6px 0;cursor:pointer;position:relative;overflow:hidden;}
        .progress-bar{height:100%;background:var(--theme);border-radius:2px;width:0%;transition:width 0.1s linear;}
        .volume{display:flex;align-items:center;gap:6px;}
        .volume input{width:90px;accent-color:var(--theme);}
        
        /* === 相册主体 === */
        main{max-width:900px;margin:0 auto;padding:0 20px 60px;}
        .section-title{font-size:1.5rem;margin:40px 0 20px;display:flex;align-items:center;gap:10px;font-weight:500;letter-spacing:1px;}
        .section-title::before{content:"";width:5px;height:22px;background:var(--theme);border-radius:3px;}
        
        /* === 图片网格 === */
        .gallery{display:grid;grid-template-columns:repeat(2,1fr);gap:30px;}
        .polaroid{position:relative;background:#000;border:5px solid #000;border-radius:5px;box-shadow:0 0 0 2px #444,0 8px 24px rgba(0,0,0,.6);cursor:zoom-in;transform-origin:center;transition:transform 0.2s ease,box-shadow 0.2s;}
        .polaroid:hover{transform:scale(1.02);box-shadow:0 0 0 2px #444,0 12px 32px rgba(0,0,0,.7);}
        .polaroid::before,.polaroid::after{content:"";position:absolute;left:0;right:0;height:10px;background:repeating-linear-gradient(90deg,#000 0 6px,transparent 6px 12px);}
        .polaroid::before{top:-7px;}
        .polaroid::after{bottom:-7px;}
        .polaroid img{width:100%;height:180px;object-fit:cover;display:block;}
        
        /* === 预览层 - 新布局 === */
        .preview-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, .96);
            z-index: 9999;
            display: none;
            align-items: center;
            justify-content: center;
            user-select: none;
            touch-action: pan-y;
        }

        .preview-container {
            width: 100%;
            height: 100%;
            max-width: 900px;
            display: flex;
            flex-direction: column;
            padding: 50px 20px 20px;
            position: relative;
        }

        /* 关闭按钮 */
        .preview-close-fixed {
            position: fixed;
            top: 15px;
            right: 15px;
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: rgba(255, 255, 255, .15);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 24px;
            font-weight: 300;
            line-height: 1;
            z-index: 10000;
            border: none;
            backdrop-filter: blur(10px);
            transition:all 0.3s;
        }

        .preview-close-fixed:hover {
            background: rgba(255, 255, 255, .25);
            transform:rotate(90deg);
        }

        /* 顶部标题栏 */
        .preview-header {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 0 15px;
            flex-shrink: 0;
        }

        .preview-title {
            color: #fff;
            font-size: 1.15rem;
            font-weight: 400;
            text-align: center;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            max-width: 80%;
            font-family:var(--font-serif);
            letter-spacing:1px;
        }

        /* 中间大图区 */
        .preview-main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            min-height: 0;
            overflow: hidden;
        }

        .preview-img-wrapper {
            position: relative;
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            touch-action: none;
        }

        .preview-img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            border-radius: 8px;
            transition: transform 0.3s ease;
            user-select: none;
            -webkit-user-drag: none;
            box-shadow:0 4px 20px rgba(0,0,0,.3);
        }

        .preview-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 44px;
            height: 44px;
            border-radius: 50%;
            background: rgba(255, 255, 255, .12);
            color: #fff;
            display: grid;
            place-content: center;
            cursor: pointer;
            font-size: 24px;
            transition: all 0.3s;
            z-index: 10;
            border:none;
        }

        .preview-nav:hover {
            background: rgba(255, 255, 255, .25);
            transform:translateY(-50%) scale(1.1);
        }

        .preview-nav.prev { left: 5px; }
        .preview-nav.next { right: 5px; }

        /* 滑动提示 */
        .swipe-hint {
            position: absolute;
            bottom: 80px;
            left: 50%;
            transform: translateX(-50%);
            color: rgba(255, 255, 255, .5);
            font-size: 12px;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.3s;
            font-weight:300;
            letter-spacing:1px;
        }

        .swipe-hint.show {
            opacity: 1;
        }

        /* 底部区域 */
        .preview-footer {
            flex-shrink: 0;
            padding-top: 15px;
        }

        /* 缩略图列表 */
        .thumb-list {
            display: flex;
            gap: 8px;
            justify-content: center;
            overflow-x: auto;
            padding: 5px;
            scrollbar-width: thin;
            scrollbar-color: rgba(255,255,255,.2) transparent;
        }
        
        .thumb-list::-webkit-scrollbar {
            height: 4px;
        }
        .thumb-list::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,.2);
            border-radius: 2px;
        }

        .thumb-item {
            width: 70px;
            height: 52px;
            border-radius: 6px;
            overflow: hidden;
            cursor: pointer;
            border: 2px solid transparent;
            transition: all 0.3s;
            flex-shrink: 0;
            opacity:0.7;
        }

        .thumb-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .thumb-item.active {
            border-color: var(--theme);
            opacity:1;
            transform:scale(1.05);
        }

        .thumb-item:hover {
            opacity:1;
            transform: scale(1.05);
        }
        
        /* === 右下角固定按钮组 === */
        .float-buttons{position:fixed;right:20px;bottom:30px;z-index:100;display:flex;flex-direction:column;gap:12px;}
        .float-btn{width:50px;height:50px;border-radius:50%;color:#fff;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:20px;box-shadow:0 4px 12px rgba(0,0,0,.3);transition:all 0.3s ease;text-decoration:none;}
        .float-btn:hover{transform:scale(1.1);}
        
        /* 返回顶部按钮 - 默认隐藏，滚动后显示 */
        .float-btn.top{background:var(--theme);opacity:0;transform:translateY(20px);pointer-events:none;}
        .float-btn.top.visible{opacity:1;transform:translateY(0);pointer-events:auto;}
        .float-btn.top:hover{background:#ff4449;}
        
        /* 返回首页按钮 - 始终显示 */
        .float-btn.home{background:#2d2d2d;}
        .float-btn.home:hover{background:#444;}
        
        /* === 响应式 === */
        @media (min-width: 768px) {
            .gallery {grid-template-columns: repeat(3, 1fr);gap: 20px;}
            .header-subtitle{font-size:2rem;}
        }
        @media (max-width: 600px){
            .top-bar{height:48px;}
            .top-bar-title{font-size:1.1rem;letter-spacing:2px;}
            .header-subtitle{font-size:1.4rem;letter-spacing:2px;}
            .music-player{margin-top:-100px;padding:15px;}
            .polaroid img{height:auto;aspect-ratio:1/1;}
            .float-buttons{right:15px;bottom:20px;}
            .float-btn{width:45px;height:45px;font-size:18px;}
            
            .preview-container { padding: 45px 10px 10px; }
            .preview-close-fixed { width: 40px; height: 40px; font-size: 20px; top:10px; right:10px;}
            .preview-title { font-size: 1rem; max-width: 75%; }
            .preview-nav { width: 36px; height: 36px; font-size: 20px; }
            .thumb-item { width: 55px; height: 40px; }
        }
        @media(max-width: 480px){
            .music-player{margin-top:-80px;}
            .player-info .title{font-size:12px;}
            .section-title{font-size:1.3rem;}
        }
    </style>
</head>
<body>
    <!-- 透明顶栏 -->
    <div class="top-bar">
        <div class="top-bar-title"><?php echo htmlspecialchars($albumTitle); ?></div>
    </div>

    <!-- 头部大图 -->
    <header>
        <div class="header-content">
            <div class="header-subtitle"><?php echo htmlspecialchars($albumDesc); ?></div>
        </div>
    </header>

    <!-- 音乐播放器 -->
    <div class="music-player">
        <button id="playBtn" class="player-btn" title="播放/暂停"><span class="tri-play"></span></button>
        <div class="player-info">
            <div class="title"><?php echo htmlspecialchars($options->musicTitle); ?></div>
            <div class="progress" id="progressBar"><div class="progress-bar"></div></div>
            <div class="time"><span id="curTime">00:00</span> / <span id="totTime">00:00</span></div>
        </div>
        <div class="volume"><span style="font-size:18px;">🎼</span><input type="range" id="volumeRange" min="0" max="1" step="0.05" value="0.6"></div>
        <audio id="audio" src="<?php echo htmlspecialchars($options->musicUrl); ?>"></audio>
    </div>

    <main>
        <?php if (empty($articles)): ?>
            <div style="text-align:center; padding:60px;">
                <i class="fas fa-images" style="font-size:4rem; color:#ccc;"></i>
                <p style="margin-top:20px; color:#888; font-weight:300;">暂无图片</p>
            </div>
        <?php else: ?>
            <?php 
            $globalIndex = 0;
            foreach ($articles as $article): 
                $articleTitle = is_array($article) ? ($article['title'] ?? '无标题') : (method_exists($article, 'getTitle') ? $article->getTitle() : '无标题');
                $images = is_array($article) ? ($article['images'] ?? []) : (method_exists($article, 'getImages') ? $article->getImages() : []);
            ?>
                <h2 class="section-title"><?php echo htmlspecialchars($articleTitle); ?></h2>
                <div class="gallery">
                    <?php foreach ($images as $img): 
                        $imgUrl = is_array($img) ? ($img['url'] ?? '') : $img;
                        $imgThumb = is_array($img) ? ($img['thumb'] ?? $imgUrl) : $img;
                        $imgTitle = is_array($img) ? ($img['title'] ?? '') : '';
                    ?>
                        <div class="polaroid" 
                             data-index="<?php echo $globalIndex; ?>"
                             data-url="<?php echo htmlspecialchars($imgUrl); ?>" 
                             data-title="<?php echo htmlspecialchars($imgTitle); ?>"
                             data-article-title="<?php echo htmlspecialchars($articleTitle); ?>"
                             data-thumb="<?php echo htmlspecialchars($imgThumb); ?>">
                            <img src="<?php echo htmlspecialchars($imgThumb); ?>" alt="<?php echo htmlspecialchars($imgTitle); ?>" loading="lazy">
                        </div>
                        <?php $globalIndex++; ?>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </main>

    <!-- 右下角固定按钮组 -->
    <div class="float-buttons">
        <button class="float-btn top" id="backToTop" title="返回顶部">
            <i class="fas fa-arrow-up"></i>
        </button>
        <a href="<?php \Widget\Options::alloc()->siteUrl(); ?>" class="float-btn home" title="返回首页">
            <i class="fas fa-home"></i>
        </a>
    </div>

    <!-- 预览层 -->
    <div class="preview-overlay" id="previewOverlay">
        <!-- 关闭按钮 -->
        <button class="preview-close-fixed" id="previewClose" title="关闭">&#10005;</button>
        
        <div class="preview-container">
            <!-- 顶部标题栏 -->
            <div class="preview-header">
                <h3 class="preview-title" id="previewTitle">文章标题</h3>
            </div>
            
            <!-- 中间大图区 -->
            <div class="preview-main" id="previewMain">
                <button class="preview-nav prev" id="previewPrev" aria-label="上一张">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <div class="preview-img-wrapper" id="imgWrapper">
                    <img class="preview-img" id="previewImg" src="" alt="" draggable="false">
                </div>
                <button class="preview-nav next" id="previewNext" aria-label="下一张">
                    <i class="fas fa-chevron-right"></i>
                </button>
                <div class="swipe-hint" id="swipeHint">左右滑动切换图片</div>
            </div>
            
            <!-- 底部缩略图 -->
            <div class="preview-footer">
                <div class="thumb-list" id="thumbList"></div>
            </div>
        </div>
    </div>

    <script>
        // 收集所有图片用于预览
        const allImages = [];
        document.querySelectorAll('.polaroid').forEach(el => {
            allImages.push({
                url: el.dataset.url,
                thumb: el.dataset.thumb,
                title: el.dataset.title,
                articleTitle: el.dataset.articleTitle
            });
        });

        // 预览功能
        const overlay = document.getElementById('previewOverlay');
        const previewImg = document.getElementById('previewImg');
        const previewTitle = document.getElementById('previewTitle');
        const previewClose = document.getElementById('previewClose');
        const previewPrev = document.getElementById('previewPrev');
        const previewNext = document.getElementById('previewNext');
        const thumbList = document.getElementById('thumbList');
        const imgWrapper = document.getElementById('imgWrapper');
        const swipeHint = document.getElementById('swipeHint');
        let currentIndex = 0;

        // 触摸滑动相关变量
        let touchStartX = 0;
        let touchEndX = 0;
        let touchStartY = 0;
        let isSwiping = false;

        // 生成缩略图
        function generateThumbs() {
            thumbList.innerHTML = allImages.map((img, idx) => `
                <div class="thumb-item ${idx === currentIndex ? 'active' : ''}" data-index="${idx}">
                    <img src="${img.thumb}" alt="">
                </div>
            `).join('');
            
            // 绑定缩略图点击
            thumbList.querySelectorAll('.thumb-item').forEach(item => {
                item.addEventListener('click', () => {
                    currentIndex = parseInt(item.dataset.index);
                    updatePreview();
                });
            });
        }

        // 更新预览内容
        function updatePreview() {
            const current = allImages[currentIndex];
            previewImg.src = current.url;
            previewTitle.textContent = current.articleTitle || current.title || '图片预览';
            
            // 更新缩略图高亮
            thumbList.querySelectorAll('.thumb-item').forEach((item, idx) => {
                item.classList.toggle('active', idx === currentIndex);
                if (idx === currentIndex) {
                    item.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                }
            });
        }

        // 打开预览
        function openPreview(index) {
            currentIndex = index;
            generateThumbs();
            updatePreview();
            overlay.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            document.querySelector('.music-player').style.visibility = 'hidden';
            
            // 显示滑动提示（首次使用时）
            if (!localStorage.getItem('previewHintShown')) {
                swipeHint.classList.add('show');
                setTimeout(() => {
                    swipeHint.classList.remove('show');
                }, 2000);
                localStorage.setItem('previewHintShown', 'true');
            }
        }

        // 关闭预览
        function closePreview() {
            overlay.style.display = 'none';
            document.body.style.overflow = '';
            document.querySelector('.music-player').style.visibility = 'visible';
        }

        // 切换到上一张
        function prevImage() {
            currentIndex = (currentIndex - 1 + allImages.length) % allImages.length;
            updatePreview();
            showSwipeFeedback('left');
        }

        // 切换到下一张
        function nextImage() {
            currentIndex = (currentIndex + 1) % allImages.length;
            updatePreview();
            showSwipeFeedback('right');
        }

        // 滑动反馈动画
        function showSwipeFeedback(direction) {
            const img = previewImg;
            img.style.transform = `translateX(${direction === 'left' ? '20px' : '-20px'})`;
            setTimeout(() => {
                img.style.transform = 'translateX(0)';
            }, 300);
        }

        // 为所有 polaroid 绑定点击
        document.querySelectorAll('.polaroid').forEach((el) => {
            el.addEventListener('click', () => {
                const index = parseInt(el.dataset.index);
                openPreview(index);
            });
        });

        // 关闭按钮
        previewClose.onclick = closePreview;

        // 左右导航按钮
        previewPrev.onclick = prevImage;
        previewNext.onclick = nextImage;

        // 点击空白处关闭
        overlay.onclick = (e) => {
            if (e.target === overlay) closePreview();
        };

        // 键盘事件
        document.addEventListener('keydown', (e) => {
            if (overlay.style.display !== 'flex') return;
            if (e.key === 'ArrowLeft') prevImage();
            if (e.key === 'ArrowRight') nextImage();
            if (e.key === 'Escape') closePreview();
        });

        // 触摸滑动事件处理
        imgWrapper.addEventListener('touchstart', (e) => {
            touchStartX = e.changedTouches[0].screenX;
            touchStartY = e.changedTouches[0].screenY;
            isSwiping = false;
        }, { passive: true });

        imgWrapper.addEventListener('touchmove', (e) => {
            if (!touchStartX) return;
            
            const touchX = e.changedTouches[0].screenX;
            const touchY = e.changedTouches[0].screenY;
            const diffX = touchStartX - touchX;
            const diffY = touchStartY - touchY;
            
            if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 10) {
                isSwiping = true;
                previewImg.style.transform = `translateX(${-diffX * 0.3}px)`;
            }
        }, { passive: true });

        imgWrapper.addEventListener('touchend', (e) => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
            touchStartX = 0;
            touchStartY = 0;
            previewImg.style.transform = '';
        });

        function handleSwipe() {
            if (!isSwiping) return;
            
            const swipeThreshold = 50;
            const diff = touchStartX - touchEndX;
            
            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0) {
                    nextImage();
                } else {
                    prevImage();
                }
            }
        }

        // 鼠标拖动支持（桌面端）
        let mouseStartX = 0;
        let isMouseDown = false;

        imgWrapper.addEventListener('mousedown', (e) => {
            mouseStartX = e.screenX;
            isMouseDown = true;
            imgWrapper.style.cursor = 'grabbing';
        });

        imgWrapper.addEventListener('mousemove', (e) => {
            if (!isMouseDown) return;
            const diffX = mouseStartX - e.screenX;
            previewImg.style.transform = `translateX(${-diffX * 0.3}px)`;
        });

        imgWrapper.addEventListener('mouseup', (e) => {
            if (!isMouseDown) return;
            isMouseDown = false;
            imgWrapper.style.cursor = 'grab';
            
            const swipeThreshold = 50;
            const diff = mouseStartX - e.screenX;
            
            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0) {
                    nextImage();
                } else {
                    prevImage();
                }
            } else {
                previewImg.style.transform = '';
            }
        });

        imgWrapper.addEventListener('mouseleave', () => {
            if (isMouseDown) {
                isMouseDown = false;
                imgWrapper.style.cursor = 'grab';
                previewImg.style.transform = '';
            }
        });

        // 音乐播放器功能
        const audio = document.getElementById('audio');
        const playBtn = document.getElementById('playBtn');
        const progressBar = document.querySelector('.progress-bar');
        const progress = document.getElementById('progressBar');
        const curTimeEl = document.getElementById('curTime');
        const totTimeEl = document.getElementById('totTime');
        const volRange = document.getElementById('volumeRange');

        playBtn.onclick = () => {
            if (audio.paused) {
                audio.play();
                playBtn.innerHTML = '<span class="tri-pause"></span>';
            } else {
                audio.pause();
                playBtn.innerHTML = '<span class="tri-play"></span>';
            }
        };

        audio.onloadedmetadata = () => {
            totTimeEl.textContent = fmtTime(audio.duration);
        };

        audio.ontimeupdate = () => {
            progressBar.style.width = `${(audio.currentTime / audio.duration) * 100}%`;
            curTimeEl.textContent = fmtTime(audio.currentTime);
        };

        progress.onclick = (e) => {
            const ratio = e.offsetX / progress.offsetWidth;
            audio.currentTime = ratio * audio.duration;
        };

        volRange.oninput = (e) => {
            audio.volume = e.target.value;
        };

        function fmtTime(sec) {
            const m = Math.floor(sec / 60);
            const s = Math.floor(sec % 60);
            return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
        }

        audio.onended = () => {
            playBtn.innerHTML = '<span class="tri-play"></span>';
        };

        // 返回顶部功能
        const backToTopBtn = document.getElementById('backToTop');
        
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                backToTopBtn.classList.add('visible');
            } else {
                backToTopBtn.classList.remove('visible');
            }
        });

        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    </script>
</body>
</html>
